import 'package:flutter/material.dart';

Color darkGreen = Color(0xff2bae5d), lightGreen = Color(0xff49bf88), darkBlue = Color(0xff424a65);
List<Map<String, dynamic>> availableTickets = [];