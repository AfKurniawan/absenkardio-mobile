class Constants {

  //static const String ROOT_URL = "http://192.168.8.125/";
  static const String ROOT_URL = "http://api.absenkardiouns.com/index.php/";
  //static const String BASE_URL = ROOT_URL +"mbahbro/management/api/index.php/";
  static const String IMG_URL = "http://admin.absenkardiouns.com/assets/faces/" ;
  static const String LOGIN_URL = ROOT_URL + "LoginUser";
  static const String REGISTER_URL = ROOT_URL + "RegisterUser";
  static const String GET_PRODUCTS_DETAIL = ROOT_URL + "GetProductDetail";
  static const String UPLOAD_IMAGE = "http://admin.absenkardiouns.com/upload.php";
  static const String CHECKIN_URL = ROOT_URL + "CheckinUser";
  static const String CHECK_LAST_CHECKIN = ROOT_URL + "CheckLastCheckin";
  static const String CHECKOUT_URL = ROOT_URL + "CheckoutUser";
  static const String UPDATE_PROFILE_URL = ROOT_URL + "UpdateProfile";

}