package id.prodi.absensi_prodi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
